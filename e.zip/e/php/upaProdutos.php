<?php

require_once('../php/vendaDao.php');    
require_once('../php/venda.php');


$p1 = new Venda($_POST['nomeItem'], $_POST["quantidade"], $_POST["peso"], $_POST["dataValidade"], $_POST["descricao"], $_POST["embalagem"], $_POST["cidade"], $_POST["bairro"], $_POST["rua"], $_POST["preco"]);

if ($_POST["complemento"]!==null){
    $p1->set_complemento($_POST["complemento"]);
}

$vdao = New vendaDAO();
$vdao->inserir($p1);

//redireciona para o listar.php
//header("Location: listar.php");






?>