CREATE TABLE  Venda 
(	codProduto serial, 
	nomeItem VARCHAR(200) NOT NULL,
 	quantidade VARCHAR(200) NOT NULL,
	peso VARCHAR(100) NOT NULL,
	dataValidade date NOT NULL, 
	descricao VARCHAR(300), 
	embalagem VARCHAR(100),
 	cidade VARCHAR(100) NOT NULL, 
 	bairro VARCHAR(100) NOT NULL, 
 	rua VARCHAR(100) NOT NULL, 
 	complemento VARCHAR(300), 
 	preco numeric(9,2) NOT NULL, 
	 CONSTRAINT "vendaPK" PRIMARY KEY (codProduto) 
) ;



CREATE TABLE  Usuario (	
	codUsuario serial,
	nomeUsuario VARCHAR(300) NOT NULL,
	email VARCHAR(300) NOT NULL,
	senha VARCHAR(40) NOT NULL,
	CONSTRAINT "usuarioPK" PRIMARY KEY (codUsuario)
) ;
