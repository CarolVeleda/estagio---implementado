<?php

include_once('usuario.php');

class usuarioDAO{

	private function conexao(){
		$scon="port=5432 dbname=estagio user=postgres password=postgres";
		return pg_connect($scon);
    }
    
    public function inserir($u){
		$conn = $this->conexao();
		$sql ="INSERT INTO usuario (nomeusuario,email,senha) VALUES ($1,$2,$3) RETURNING codusuario"; 
		$vetor = array($u->get_nome(), $u->get_email(), $u->get_senha());
		
		$res = pg_query_params($conn, $sql, $vetor);
		$linha = pg_fetch_assoc($res);
        $u->set_codUsuario(intval($linha['codusuario']));
		pg_close($conn);
    }
    
    public function deletar($cod){
		$conn = $this->conexao();
		$sql = "DELETE FROM usuario WHERE codusuario = $1";
		$res = pg_query_params($conn, $sql, array($cod));
		pg_close($conn);
    }
    
    public function alterar($u){
		$conn = $this->conexao();
		$sql="UPDATE usuario SET nomeusuario=$1,email=$2,senha=$3 WHERE codusuario = $4 ";
        $v = array($u->get_nome(), $u->get_email(), $u->get_senha(), $u->get_codUsuario());
        
        $res = pg_query_params($conn, $sql,$v);
		
    }
    
    public function login($email,$senha){
        $conn = $this->conexao();
        $sql="SELECT * FROM Funcionario WHERE email = $1 and senha= $2";
        $v = array($email,$senha);
        $res = pg_query_params($conn, $sql,$v);
        $nl = pg_num_rows($res);

        if ($nl)
        //$u= new Usuario($, $,$);

    }



}


//$mdao = New vendaDAO();
//$lista = $mdao->listar();
//print_r($lista);

?>